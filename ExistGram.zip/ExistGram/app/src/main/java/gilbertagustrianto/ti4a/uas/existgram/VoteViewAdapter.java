package gilbertagustrianto.ti4a.uas.existgram;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class VoteViewAdapter extends RecyclerView.Adapter<VoteViewAdapter.ViewHolder> {

    private List<Profile> mData;
    private Context mContext;


    public VoteViewAdapter(List<Profile> mData, Context mContext) {
        this.mData = mData;
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public VoteViewAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VoteViewAdapter.ViewHolder holder, int position) {
        Profile profile = mData.get(position);
        holder.bindTo(profile);
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView tvNama, tvSubnama, tvCaption, tvCount;
        private ImageView ivProfile;
        private ImageButton ivPost;
        private int mLikes = 0;
        private long mLastClickTime = 0;
            int i = 0;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tvNama = itemView.findViewById(R.id.tv_nama);
            tvSubnama = itemView.findViewById(R.id.tv_subNama);
            tvCaption = itemView.findViewById(R.id.tv_caption);
            tvCount = itemView.findViewById(R.id.tv_count);
            ivProfile = itemView.findViewById(R.id.iv_profile);
            ivPost = itemView.findViewById(R.id.iv_post);

        ivPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // mis-clicking prevention, using threshold of 1000 ms

                if (SystemClock.elapsedRealtime() - mLastClickTime < 1000){
                    return;
                }
                mLastClickTime = SystemClock.elapsedRealtime();

                mLikes ++;
                tvCount.setText(String.valueOf(mLikes));
            }
        });

//            ivPost.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    i++;
//                    Handler handler = new Handler();
//                    handler.postDelayed(new Runnable() {
//                        @Override
//                        public void run() {
//                            if (i == 2 ) {
//                                mLikes ++;
//                                tvCount.setText(String.valueOf(mLikes));
//                            }
//                        }
//                    }, 100);
//                }
//            });

            tvCount.setText(String.valueOf(mLikes).toString());
        }

        void bindTo(Profile profile) {
            tvNama.setText(profile.getNama());
            tvSubnama.setText(profile.getSubnama());
            tvCaption.setText(profile.getCaption());
            tvCount.setText(profile.getDataLike());
            Glide.with(mContext).load(profile.getImageResource()).into(ivPost);
            Glide.with(mContext).load(profile.getImageResource()).into(ivProfile);

        }

    }
}
