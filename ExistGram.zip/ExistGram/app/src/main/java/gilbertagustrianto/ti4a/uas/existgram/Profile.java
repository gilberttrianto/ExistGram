package gilbertagustrianto.ti4a.uas.existgram;

public class Profile {
    private String nama;
    private String subnama;
    private String caption;
    private int imageResource;
    private String dataLike;

    public Profile(String nama, String subnama, String caption, int imageResource, String dataLike) {
        this.nama = nama;
        this.subnama = subnama;
        this.caption = caption;
        this.imageResource = imageResource;
        this.dataLike = dataLike;
    }

    public String getNama()
    {
        return nama;
    }

    public String getSubnama() {
        return subnama;
    }

    public String getCaption() {
        return caption;
    }

    public int getImageResource() {
        return imageResource;
    }

    public String getDataLike() {
        return dataLike;
    }
}
