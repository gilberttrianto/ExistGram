package gilbertagustrianto.ti4a.uas.existgram;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.res.TypedArray;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvVote;
    private List<Profile> mProfileData = new ArrayList<>();
    private VoteViewAdapter instaViewAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvVote = findViewById(R.id.rv_Vote);
        rvVote.setLayoutManager((new LinearLayoutManager(this)));
        instaViewAdapter = new VoteViewAdapter(mProfileData, this);
        rvVote.setAdapter(instaViewAdapter);

        insertDummyData();
    }

    private void insertDummyData() {
        String[] profileName = getResources().getStringArray(R.array.profile_name);
        String[] profileSubName = getResources().getStringArray(R.array.profile_subname);
        String[] profileCaption = getResources().getStringArray(R.array.profile_caption);
        String[] profileLike = getResources().getStringArray(R.array.profile_count);
        TypedArray profileImages = getResources().obtainTypedArray(R.array.profile_images);

        mProfileData.clear();

        for (int i = 0; i < profileName.length; i++) {
            mProfileData.add(new Profile(profileName[i], profileSubName[i], profileCaption[i], profileImages.getResourceId(i,0), profileLike[i] ));
        }

        profileImages.recycle();

        instaViewAdapter.notifyDataSetChanged();
    }
}